def translatePath(path):
	return path
