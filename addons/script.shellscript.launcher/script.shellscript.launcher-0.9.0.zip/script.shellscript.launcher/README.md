# Kodi Shell Script Launcher

Kodi addon to execute shell scripts or commands. It displays a menu to select the script that shall be executed. The menu is defined in a text file, that is ":" separated (see example.menu). The menu file can be selected in the addon settings.

[Version 0.9.0](https://github.com/wastis/LinuxAddonRepo)

<img src="resources/media/icon.png" alt="drawing" width="200"/> 

2022 wastis


